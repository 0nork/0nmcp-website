// 0nMCP Chrome Extension — Background Service Worker
// Minimal placeholder for future features (context menus, notifications, etc.)

chrome.runtime.onInstalled.addListener(() => {
  console.log('0nMCP extension installed')
})
